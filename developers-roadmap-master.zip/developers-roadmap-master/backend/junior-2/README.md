# Backend Junior-2

Advanced topics for the junior level

## Areas of expertise 
- [Haskell](./haskell.md)
- [Linux administration](./linux.md)

## Required resources

- _Code Craft: The Practice of Writing Excellent Code_ by Pete Goodliffe