# Backend Middle-1

Middle back-end developer 1 level.

## Areas of expertise

- [Haskell](./haskell.md)
- [Linux](./linux.md)
- [Databases](./db.md)
- [Networking](./networking.md)

## Required resources

  TODO
