# Front-end Senior Developer
Senior Front-end Developer умеет спроектировать сложные нетривиальные поддерживаемые решения, заложить гибкую архитектуру, способную к развитию и рефакторингу, который не застопорит всю разработку. Знает, как следить за системой, чтобы быстро и эффективно вылавливать heisenbugs, как мониторить и отслеживать деградации и аномалии в работе системы. Умеет сам быстро изучать новые темы, умеет находить области для дальнейшего развития, даже если сейчас нет активной практической потребности в доп. знаниях.

## Области знаний
> TODO fill areas
- Deep knowledge of architecture principles
- Deep knowledge of architectures of different big applications
- Lot of experience of designing different domains
- Skills of configuring effective logging and monitoring systems
- Ability to effectively learn domain deeply
- Great communication skills
