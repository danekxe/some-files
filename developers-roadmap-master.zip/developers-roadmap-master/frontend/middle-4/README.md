# Front-end Middle Developer 4 level
Middle Front-end Developer 4 level отлично знает принципы разработки поддерживаемых и гибких решений. Уже начинает активно изучать архитектурные принципы, но ещё не всегда может грамотно их применить самостоятельно.

## Области знаний
> TODO fill areas
- Deep FP knowledge
    - Fantasy Land specification
    - CPS principles
- Basic architecture knowledge
    - Client-server architecture principles
    - Layered architectures
    - Message-based and event-sources architectures
- Design of eDSL
- Architecture of frameworks (learn about at least 3 of them):
    - React
    - Vue
    - Angular
    - Backbone
    - ExtJS
