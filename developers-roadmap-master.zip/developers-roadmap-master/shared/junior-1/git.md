# Git

* Что такое Git?
* В чём разница между Git, GitHub и GitLab?
* Что представляют из себя 3 области: Working directory, Staging area, Repository?
* Ветки
  * Что такое ветка?
  * Зачем нужны ветки?
  * Что значит "создать ветку" и "удалить ветку" (что при этом происходит)?
  * Как посмотреть список веток?
  * Как сменить ветку?
  * Как создать ветку?
  * Как переименовать ветку?
  * Как удалить ветку?
* Для чего нужен файл `.gitignore`?
* `git config`: что позволяет делать и какие три уровня конфигурации есть?
* Что делают, как и зачем использовать команды:
  * `add`
  * `commit`
    * Как и при каких условиях можно сделать коммит, не написав перед этим явно `git add`?
    * Как написать сообщение для коммита не открывая редактора?
  * `push`
  * `fetch`
  * `merge`
    * Что такое fast-forward merge?
    * Что делают флаги `--squash` и `--no-ff`?
  * `pull`
* Что такое Pull Request (или Merge Request)?
* Как посмотреть историю коммитов?

### Ресурсы
* [Atlassian Git Tutorial](https://www.atlassian.com/git)
* [Скринкаст по Git](https://learn.javascript.ru/screencast/git#intro-starting-video)
* [Understanding Git — Data Model](https://medium.com/hackernoon/https-medium-com-zspajich-understanding-git-data-model-95eb16cc99f5)
