# Shared topics Junior-1
Junior developer 1 level is capable of solving simple local tasks under supervision of senior colleagues.

## Areas of expertise 
- [Git](./git.md)
