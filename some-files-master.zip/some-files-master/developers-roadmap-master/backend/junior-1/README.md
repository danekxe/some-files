# Backend Junior-1
Junior back-end developer 1 level is capable of solving simple local tasks under supervision of senior colleagues.

## Areas of expertise 
- [Haskell](./haskell.md)
- [Databases](./db.md)
- [Git](../../shared/junior-1/git.md)
