# Список уровней:
1. **Junior:**
    * [junior-1](./junior-1/README.md)
    * [junior-2](./junior-2/README.md)
    * [junior-3](./junior-3/README.md)

1. **Middle**
    * [middle-1](./middle-1/README.md)
    * [middle-2](./middle-2/README.md)
    * [middle-3](./middle-3/README.md)
    * [middle-4](./middle-4/README.md)

1. **Senior**
    * [senior](./senior/README.md)
