# Мобильные браузеры

* Как работает hover в мобильных браузерах?
* События touch и pointer
  * Что такое?
  * Зачем нужны?
  * Какие бывают?
* Как работают события мыши в мобильных браузерах? Зачем нужна задержка при клике и как ее избежать?

### Ресурсы

* [Язык жестов — WSD в Минске, 2018 ](https://www.youtube.com/watch?v=bjxjAESwejE&t=640s)
* [Touch/Pointer events and demos](https://patrickhlauke.github.io/touch/)
