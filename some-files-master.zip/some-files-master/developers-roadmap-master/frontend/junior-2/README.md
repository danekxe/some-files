# Front-end Junior 2 level

- [HTML](./html.md)
- [CSS](./css.md)
- [JavaScript](./js.md)
- [DOM](./dom.md)
- [Тестирование](./testing.md)
- [Мобильные браузеры](./mobile.md)
- [Работа с датой](./time.md)
- [Литература](./books.md)

## Специфично для нашего стека

- [TypeScript](./ts.md)
- [React](./react.md)
