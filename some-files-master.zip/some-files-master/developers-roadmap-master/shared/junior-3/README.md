# Shared topics Junior-3
Junior developer 3 level is capable of solving simple local tasks under supervision of senior colleagues.

## Areas of expertise 
- [Git](./git.md)
